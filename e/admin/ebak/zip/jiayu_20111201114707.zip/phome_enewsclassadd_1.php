<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `phome_enewsclassadd`;");
E_C("CREATE TABLE `phome_enewsclassadd` (
  `classid` smallint(6) NOT NULL default '0',
  `classtext` mediumtext NOT NULL,
  `ttids` text NOT NULL,
  PRIMARY KEY  (`classid`)
) ENGINE=MyISAM DEFAULT CHARSET=gbk");
E_D("replace into `phome_enewsclassadd` values('1','','');");
E_D("replace into `phome_enewsclassadd` values('2','','');");
E_D("replace into `phome_enewsclassadd` values('3','','');");
E_D("replace into `phome_enewsclassadd` values('4','','');");
E_D("replace into `phome_enewsclassadd` values('6','','');");
E_D("replace into `phome_enewsclassadd` values('7','','');");
E_D("replace into `phome_enewsclassadd` values('8','','');");
E_D("replace into `phome_enewsclassadd` values('9','','');");
E_D("replace into `phome_enewsclassadd` values('10','','');");
E_D("replace into `phome_enewsclassadd` values('11','','');");
E_D("replace into `phome_enewsclassadd` values('12','','');");
E_D("replace into `phome_enewsclassadd` values('13','','');");
E_D("replace into `phome_enewsclassadd` values('40','','');");
E_D("replace into `phome_enewsclassadd` values('76','','');");
E_D("replace into `phome_enewsclassadd` values('77','','');");
E_D("replace into `phome_enewsclassadd` values('78','','');");
E_D("replace into `phome_enewsclassadd` values('79','','');");
E_D("replace into `phome_enewsclassadd` values('86','','');");
E_D("replace into `phome_enewsclassadd` values('87','','');");
E_D("replace into `phome_enewsclassadd` values('103','','');");
E_D("replace into `phome_enewsclassadd` values('104','','');");
E_D("replace into `phome_enewsclassadd` values('105','','');");
E_D("replace into `phome_enewsclassadd` values('106','','');");
E_D("replace into `phome_enewsclassadd` values('107','','');");
E_D("replace into `phome_enewsclassadd` values('112','','');");
E_D("replace into `phome_enewsclassadd` values('117','','');");
E_D("replace into `phome_enewsclassadd` values('139','','');");
E_D("replace into `phome_enewsclassadd` values('140','','');");
E_D("replace into `phome_enewsclassadd` values('141','','');");
E_D("replace into `phome_enewsclassadd` values('149','','');");
E_D("replace into `phome_enewsclassadd` values('155','','');");
E_D("replace into `phome_enewsclassadd` values('156','','');");
E_D("replace into `phome_enewsclassadd` values('157','','');");
E_D("replace into `phome_enewsclassadd` values('161','','');");
E_D("replace into `phome_enewsclassadd` values('162','','');");
E_D("replace into `phome_enewsclassadd` values('163','','');");
E_D("replace into `phome_enewsclassadd` values('164','','');");
E_D("replace into `phome_enewsclassadd` values('165','','');");
E_D("replace into `phome_enewsclassadd` values('171','','');");
E_D("replace into `phome_enewsclassadd` values('172','','');");
E_D("replace into `phome_enewsclassadd` values('186','','');");
E_D("replace into `phome_enewsclassadd` values('190','','');");
E_D("replace into `phome_enewsclassadd` values('193','','');");
E_D("replace into `phome_enewsclassadd` values('196','','');");
E_D("replace into `phome_enewsclassadd` values('203','','');");
E_D("replace into `phome_enewsclassadd` values('209','','');");
E_D("replace into `phome_enewsclassadd` values('214','','');");
E_D("replace into `phome_enewsclassadd` values('218','','');");
E_D("replace into `phome_enewsclassadd` values('221','','');");
E_D("replace into `phome_enewsclassadd` values('225','','');");
E_D("replace into `phome_enewsclassadd` values('231','','');");
E_D("replace into `phome_enewsclassadd` values('232','','');");
E_D("replace into `phome_enewsclassadd` values('237','','');");
E_D("replace into `phome_enewsclassadd` values('238','','');");
E_D("replace into `phome_enewsclassadd` values('242','','');");
E_D("replace into `phome_enewsclassadd` values('243','','');");
E_D("replace into `phome_enewsclassadd` values('267','','');");
E_D("replace into `phome_enewsclassadd` values('268','','');");
E_D("replace into `phome_enewsclassadd` values('269','','');");
E_D("replace into `phome_enewsclassadd` values('277','','');");
E_D("replace into `phome_enewsclassadd` values('278','','');");
E_D("replace into `phome_enewsclassadd` values('281','','');");
E_D("replace into `phome_enewsclassadd` values('280','','');");
E_D("replace into `phome_enewsclassadd` values('282','','');");
E_D("replace into `phome_enewsclassadd` values('283','','');");

@include("../../inc/footer.php");
?>