<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `phome_enewsuserjs`;");
E_C("CREATE TABLE `phome_enewsuserjs` (
  `jsid` smallint(6) NOT NULL auto_increment,
  `jsname` varchar(60) NOT NULL default '',
  `jssql` text NOT NULL,
  `jstempid` smallint(6) NOT NULL default '0',
  `jsfilename` varchar(120) NOT NULL default '',
  PRIMARY KEY  (`jsid`)
) ENGINE=MyISAM DEFAULT CHARSET=gbk");

@include("../../inc/footer.php");
?>