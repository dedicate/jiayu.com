<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `phome_enewsfile`;");
E_C("CREATE TABLE `phome_enewsfile` (
  `fileid` int(11) NOT NULL auto_increment,
  `filename` varchar(60) NOT NULL default '',
  `filesize` int(11) NOT NULL default '0',
  `path` varchar(20) NOT NULL default '',
  `adduser` varchar(30) NOT NULL default '',
  `filetime` datetime NOT NULL default '0000-00-00 00:00:00',
  `classid` smallint(6) NOT NULL default '0',
  `no` varchar(60) NOT NULL default '',
  `type` tinyint(4) NOT NULL default '0',
  `onclick` int(11) NOT NULL default '0',
  `id` bigint(20) NOT NULL default '0',
  `cjid` bigint(20) NOT NULL default '0',
  `fpath` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`fileid`),
  KEY `id` (`id`),
  KEY `type` (`type`),
  KEY `classid` (`classid`)
) ENGINE=MyISAM AUTO_INCREMENT=262 DEFAULT CHARSET=gbk");
E_D("replace into `phome_enewsfile` values('31','6b1ebed16f6af4cfa1aa61b84465536b.jpg','172412','2011-10-26','admin','2011-10-26 15:18:47','6','[URL]6b1ebed16f6af4cfa1aa61b84465536b.jpg','1','0','11','0','0');");
E_D("replace into `phome_enewsfile` values('32','077c5d98e793846ca118914ca14063b5.jpg','203979','2011-10-26','admin','2011-10-26 15:19:51','6','[URL]077c5d98e793846ca118914ca14063b5.jpg','1','0','21','0','0');");
E_D("replace into `phome_enewsfile` values('187','cddab821d9941cacc4fcf12387048a6c.jpg','175653','2011-11-07','jiayuadmin','2011-11-07 13:57:55','79','20111030052721868.jpg','1','0','707','0','0');");
E_D("replace into `phome_enewsfile` values('188','4fa6791c17286e4b8ebbfa4ba4d724a0.jpg','199984','2011-11-07','jiayuadmin','2011-11-07 13:58:20','79','20111030052734438.jpg','1','0','707','0','0');");
E_D("replace into `phome_enewsfile` values('189','7838e5689007b7e4699c3d2236764399.jpg','160575','2011-11-07','jiayuadmin','2011-11-07 13:59:01','79','20111030053117192.jpg','1','0','707','0','0');");
E_D("replace into `phome_enewsfile` values('191','c1aec72306c3852b972e0e8454dbd2e9.jpg','157617','2011-11-08','jiayuadmin','2011-11-08 09:18:12','6','20111107023915997.jpg','1','0','712','0','0');");
E_D("replace into `phome_enewsfile` values('192','7e8ec0aa0397d599b013b957e148a696.jpg','179560','2011-11-08','jiayuadmin','2011-11-08 09:22:27','6','20111107093417569.jpg','1','0','713','0','0');");
E_D("replace into `phome_enewsfile` values('193','fc03bc0683948a3f041f0264c8589462.jpg','138748','2011-11-08','jiayuadmin','2011-11-08 09:22:42','6','20111107093443481.jpg','1','0','713','0','0');");
E_D("replace into `phome_enewsfile` values('194','af427a1eacabff59c1289201600e9b4c.jpg','180560','2011-11-08','jiayuadmin','2011-11-08 09:25:13','6','20111107035845686.jpg','1','0','714','0','0');");
E_D("replace into `phome_enewsfile` values('205','2c2b0d0c813556417d7a7aacbbc4aec6.jpg','183639','2011-11-09','admin','2011-11-09 10:01:02','79','[URL]2c2b0d0c813556417d7a7aacbbc4aec6.jpg','1','0','753','0','0');");
E_D("replace into `phome_enewsfile` values('206','e8c5ecef72c816baf604db795a9c70aa.jpg','207535','2011-11-09','admin','2011-11-09 10:01:03','79','[URL]e8c5ecef72c816baf604db795a9c70aa.jpg','1','0','753','0','0');");
E_D("replace into `phome_enewsfile` values('207','da2f68b91faa95e20c45b1f11ed1a8d9.jpg','187764','2011-11-09','admin','2011-11-09 10:01:09','79','[URL]da2f68b91faa95e20c45b1f11ed1a8d9.jpg','1','0','754','0','0');");
E_D("replace into `phome_enewsfile` values('208','b68cc7de50cb3c312997ba71dc94b7cf.jpg','208139','2011-11-09','admin','2011-11-09 10:01:17','79','[URL]b68cc7de50cb3c312997ba71dc94b7cf.jpg','1','0','755','0','0');");
E_D("replace into `phome_enewsfile` values('24','448fb2d3dbdf505b845f23e583a90a7e.jpg','216977','2011-10-26','admin','2011-10-26 12:59:59','85','2_110916171848_1.jpg','1','0','73','0','0');");
E_D("replace into `phome_enewsfile` values('204','d05a5e08693321fa1164b7341e0a73e3.jpg','205562','2011-11-08','jiayuadmin','2011-11-08 15:53:53','79','[URL]d05a5e08693321fa1164b7341e0a73e3.jpg','1','0','751','0','0');");
E_D("replace into `phome_enewsfile` values('203','c218c7f71ff821e04ac270eca7290fda.jpg','188637','2011-11-08','jiayuadmin','2011-11-08 15:53:53','79','[URL]c218c7f71ff821e04ac270eca7290fda.jpg','1','0','751','0','0');");
E_D("replace into `phome_enewsfile` values('202','3d99162fc301241935b34cab86a946a6.jpg','195592','2011-11-08','jiayuadmin','2011-11-08 15:53:53','79','[URL]3d99162fc301241935b34cab86a946a6.jpg','1','0','751','0','0');");
E_D("replace into `phome_enewsfile` values('29','e33d93f63d31376c56c2418b0e557ca8.jpg','163603','2011-10-26','admin','2011-10-26 15:17:24','6','[URL]e33d93f63d31376c56c2418b0e557ca8.jpg','1','0','9','0','0');");
E_D("replace into `phome_enewsfile` values('30','08b19030b7f1e9f3053948d35a94c215.jpg','159547','2011-10-26','admin','2011-10-26 15:17:52','6','[URL]08b19030b7f1e9f3053948d35a94c215.jpg','1','0','10','0','0');");
E_D("replace into `phome_enewsfile` values('33','2fbec2942ae4a926957333fd6f534bde.jpg','169950','2011-10-26','admin','2011-10-26 15:20:33','6','[URL]2fbec2942ae4a926957333fd6f534bde.jpg','1','0','22','0','0');");
E_D("replace into `phome_enewsfile` values('34','033811fc15166d65d649345e6c029be8.jpg','169374','2011-10-26','admin','2011-10-26 15:20:34','6','[URL]033811fc15166d65d649345e6c029be8.jpg','1','0','22','0','0');");
E_D("replace into `phome_enewsfile` values('35','6749db341ac858593b72334201d43b24.jpg','196773','2011-10-26','admin','2011-10-26 15:21:27','6','[URL]6749db341ac858593b72334201d43b24.jpg','1','0','24','0','0');");
E_D("replace into `phome_enewsfile` values('36','6f8f6e3e65cc36ea0e2c45287d61f633.jpg','159327','2011-10-26','admin','2011-10-26 15:22:38','6','[URL]6f8f6e3e65cc36ea0e2c45287d61f633.jpg','1','0','26','0','0');");
E_D("replace into `phome_enewsfile` values('37','ef00e006c470251e9f16613d0d139b21.jpg','227214','2011-10-26','admin','2011-10-26 15:23:16','6','[URL]ef00e006c470251e9f16613d0d139b21.jpg','1','0','27','0','0');");
E_D("replace into `phome_enewsfile` values('38','d7ec36cba7bc7a2fc855f4a953e13996.jpg','207378','2011-10-26','admin','2011-10-26 15:23:17','6','[URL]d7ec36cba7bc7a2fc855f4a953e13996.jpg','1','0','27','0','0');");
E_D("replace into `phome_enewsfile` values('39','6f331bdea6a7bd488671627fb2b72e42.jpg','185881','2011-10-26','admin','2011-10-26 15:23:59','6','[URL]6f331bdea6a7bd488671627fb2b72e42.jpg','1','0','28','0','0');");
E_D("replace into `phome_enewsfile` values('40','b5a652ee239047a53b445be0fcc0c3e5.jpg','220059','2011-10-26','admin','2011-10-26 15:24:39','6','[URL]b5a652ee239047a53b445be0fcc0c3e5.jpg','1','0','111','0','0');");
E_D("replace into `phome_enewsfile` values('41','1d0fc67077bab2eb4d6189f7c44387a9.jpg','194676','2011-10-26','admin','2011-10-26 15:25:14','6','[URL]1d0fc67077bab2eb4d6189f7c44387a9.jpg','1','0','112','0','0');");
E_D("replace into `phome_enewsfile` values('43','24db6ee9503251d8332fdc11542922de.jpg','210555','2011-10-26','admin','2011-10-26 15:26:21','6','[URL]24db6ee9503251d8332fdc11542922de.jpg','1','0','114','0','0');");
E_D("replace into `phome_enewsfile` values('183','fbd83b3da97432b8fbc42da97a49dcea.jpg','55282','2011-11-05','admin','2011-11-05 20:18:15','76','20097514824537.jpg','1','0','489','0','0');");
E_D("replace into `phome_enewsfile` values('186','93d1a279ab36214ac158adb1c848b45b.jpg','115851','2011-11-07','admin','2011-11-07 10:16:38','76','δ����1.jpg','1','0','495','0','0');");
E_D("replace into `phome_enewsfile` values('197','d480988371480052eddab099fbc34016.jpg','38162','2011-11-08','admin','2011-11-08 12:46:09','3','���˴����л���.jpg','1','0','125','0','0');");
E_D("replace into `phome_enewsfile` values('201','979ba35d86efdafc7546bdd41c4b9b49.jpg','182559','2011-11-08','admin','2011-11-08 12:48:05','3','��ί���л���.jpg','1','0','125','0','0');");
E_D("replace into `phome_enewsfile` values('199','99fb256ac0dda8f9b9ecf36d0c848d18.jpg','221107','2011-11-08','admin','2011-11-08 12:46:20','3','���������л���.jpg','1','0','125','0','0');");
E_D("replace into `phome_enewsfile` values('200','15b208fb45dadac4083232823a380441.jpg','45737','2011-11-08','admin','2011-11-08 12:46:22','3','����Э �������� Ⱥ������.jpg','1','0','125','0','0');");
E_D("replace into `phome_enewsfile` values('62','fe4e0a73c533340a4bc50e5079e7c4f2.jpg','31582','2011-10-26','admin','2011-10-26 19:22:41','243','[URL]fe4e0a73c533340a4bc50e5079e7c4f2.jpg','1','0','136','0','0');");
E_D("replace into `phome_enewsfile` values('63','19bcb00a13c809195159f95d8b9494c8.jpg','32457','2011-10-26','admin','2011-10-26 19:22:42','243','[URL]19bcb00a13c809195159f95d8b9494c8.jpg','1','0','136','0','0');");
E_D("replace into `phome_enewsfile` values('64','255fa12aced030019144c7862dcd78b8.jpg','24322','2011-10-26','admin','2011-10-26 19:22:42','243','[URL]255fa12aced030019144c7862dcd78b8.jpg','1','0','136','0','0');");
E_D("replace into `phome_enewsfile` values('65','e0fb378600fcd027fb28ea5a8a747c25.jpg','23914','2011-10-26','admin','2011-10-26 19:22:42','243','[URL]e0fb378600fcd027fb28ea5a8a747c25.jpg','1','0','136','0','0');");
E_D("replace into `phome_enewsfile` values('66','2791cc54aa0ee948342ba8413fa0c9b9.jpg','55282','2011-10-26','admin','2011-10-26 19:23:12','244','[URL]2791cc54aa0ee948342ba8413fa0c9b9.jpg','1','0','137','0','0');");
E_D("replace into `phome_enewsfile` values('67','93890708ac94b5aa1d608616756f59fe.jpg','21436','2011-10-26','admin','2011-10-26 19:25:33','245','[URL]93890708ac94b5aa1d608616756f59fe.jpg','1','0','143','0','0');");
E_D("replace into `phome_enewsfile` values('68','15ee6d0fa7b2678b2df6af62d05a8f23.jpg','29076','2011-10-26','admin','2011-10-26 19:25:33','245','[URL]15ee6d0fa7b2678b2df6af62d05a8f23.jpg','1','0','143','0','0');");
E_D("replace into `phome_enewsfile` values('69','78499d63e5776a1283b33029e4cf0db9.jpg','34796','2011-10-26','admin','2011-10-26 19:25:34','245','[URL]78499d63e5776a1283b33029e4cf0db9.jpg','1','0','143','0','0');");
E_D("replace into `phome_enewsfile` values('70','a6e27dd9f6281bedc5eb9d12993a919b.jpg','22886','2011-10-26','admin','2011-10-26 19:25:34','245','[URL]a6e27dd9f6281bedc5eb9d12993a919b.jpg','1','0','143','0','0');");
E_D("replace into `phome_enewsfile` values('71','f5baefc13377fcc87b0e206dfafaa323.jpg','31497','2011-10-26','admin','2011-10-26 19:25:35','245','[URL]f5baefc13377fcc87b0e206dfafaa323.jpg','1','0','143','0','0');");
E_D("replace into `phome_enewsfile` values('72','1115247cb2eb2668fbdf1eec23142060.jpg','20971','2011-10-26','admin','2011-10-26 19:25:35','245','[URL]1115247cb2eb2668fbdf1eec23142060.jpg','1','0','143','0','0');");
E_D("replace into `phome_enewsfile` values('73','9a1df6b5d69e86df6e781bf8e3d20e30.jpg','24414','2011-10-26','admin','2011-10-26 19:25:35','245','[URL]9a1df6b5d69e86df6e781bf8e3d20e30.jpg','1','0','143','0','0');");
E_D("replace into `phome_enewsfile` values('74','7fe5ef5ff6aaf860587295ceda08bed0.jpg','34516','2011-10-26','admin','2011-10-26 19:25:36','245','[URL]7fe5ef5ff6aaf860587295ceda08bed0.jpg','1','0','143','0','0');");
E_D("replace into `phome_enewsfile` values('75','a77bfec89e990cb476b982a080e1d6d7.jpg','30244','2011-10-26','admin','2011-10-26 19:25:36','245','[URL]a77bfec89e990cb476b982a080e1d6d7.jpg','1','0','143','0','0');");
E_D("replace into `phome_enewsfile` values('76','468ea8b37dd4c7638712d0b32207c049.jpg','179024','2011-10-26','admin','2011-10-26 19:26:03','245','[URL]468ea8b37dd4c7638712d0b32207c049.jpg','1','0','144','0','0');");
E_D("replace into `phome_enewsfile` values('77','4b12a726c681e9845fdb545aadfb66ed.jpg','76320','2011-10-26','admin','2011-10-26 19:26:04','245','[URL]4b12a726c681e9845fdb545aadfb66ed.jpg','1','0','144','0','0');");
E_D("replace into `phome_enewsfile` values('78','85071d8e5cdde1f2f3c3f64c55863655.jpg','152080','2011-10-26','admin','2011-10-26 19:26:05','245','[URL]85071d8e5cdde1f2f3c3f64c55863655.jpg','1','0','144','0','0');");
E_D("replace into `phome_enewsfile` values('79','bb239ae7e024f69dd1ccf953cd592e4c.jpg','150786','2011-10-26','admin','2011-10-26 19:26:34','245','[URL]bb239ae7e024f69dd1ccf953cd592e4c.jpg','1','0','145','0','0');");
E_D("replace into `phome_enewsfile` values('80','89036f401351880c6eaa32cf8086ade7.jpg','214646','2011-10-26','admin','2011-10-26 19:26:35','245','[URL]89036f401351880c6eaa32cf8086ade7.jpg','1','0','145','0','0');");
E_D("replace into `phome_enewsfile` values('81','4f08a957645dd1629385d6ed9d550841.jpg','233673','2011-10-26','admin','2011-10-26 19:26:36','245','[URL]4f08a957645dd1629385d6ed9d550841.jpg','1','0','145','0','0');");
E_D("replace into `phome_enewsfile` values('82','e992b92507096a7d0ca4f47e3afa7292.jpg','239438','2011-10-26','admin','2011-10-26 19:26:38','245','[URL]e992b92507096a7d0ca4f47e3afa7292.jpg','1','0','145','0','0');");
E_D("replace into `phome_enewsfile` values('83','2e4a78dcf1d729f64d8616d3a1dc4be5.jpg','259689','2011-10-26','admin','2011-10-26 19:26:39','245','[URL]2e4a78dcf1d729f64d8616d3a1dc4be5.jpg','1','0','145','0','0');");
E_D("replace into `phome_enewsfile` values('84','d74386603af0ea9dbda822118769667b.jpg','141306','2011-10-26','admin','2011-10-26 19:26:40','245','[URL]d74386603af0ea9dbda822118769667b.jpg','1','0','145','0','0');");
E_D("replace into `phome_enewsfile` values('85','35ef1905be3b2946009108e00d40b4d3.jpg','262063','2011-10-26','admin','2011-10-26 19:26:41','245','[URL]35ef1905be3b2946009108e00d40b4d3.jpg','1','0','145','0','0');");
E_D("replace into `phome_enewsfile` values('86','be54bd0fdbd44e5b429650e8ec7d8a35.jpg','211929','2011-10-26','admin','2011-10-26 19:26:42','245','[URL]be54bd0fdbd44e5b429650e8ec7d8a35.jpg','1','0','145','0','0');");
E_D("replace into `phome_enewsfile` values('87','5318dafeb421f995aed0964eb4ab4c5b.jpg','97576','2011-10-26','admin','2011-10-26 19:27:00','245','[URL]5318dafeb421f995aed0964eb4ab4c5b.jpg','1','0','146','0','0');");
E_D("replace into `phome_enewsfile` values('88','4222f5e908fd636cca638d0ad8d0a41d.jpg','151136','2011-10-26','admin','2011-10-26 19:27:01','245','[URL]4222f5e908fd636cca638d0ad8d0a41d.jpg','1','0','146','0','0');");
E_D("replace into `phome_enewsfile` values('89','7562c08903324e1b08397a6bcef38c22.jpg','84715','2011-10-26','admin','2011-10-26 19:27:17','245','[URL]7562c08903324e1b08397a6bcef38c22.jpg','1','0','147','0','0');");
E_D("replace into `phome_enewsfile` values('90','b7b58fc4b4ae8419f05de87030715a45.jpg','40095','2011-10-26','admin','2011-10-26 19:27:33','245','[URL]b7b58fc4b4ae8419f05de87030715a45.jpg','1','0','148','0','0');");
E_D("replace into `phome_enewsfile` values('91','a4568a01809f6bde74369be3bad9893c.jpg','123533','2011-10-26','admin','2011-10-26 19:28:37','245','[URL]a4568a01809f6bde74369be3bad9893c.jpg','1','0','151','0','0');");
E_D("replace into `phome_enewsfile` values('92','5fe60ba1f2f2f162c2d578fa306b2f0a.jpg','141304','2011-10-26','admin','2011-10-26 19:28:37','245','[URL]5fe60ba1f2f2f162c2d578fa306b2f0a.jpg','1','0','151','0','0');");
E_D("replace into `phome_enewsfile` values('93','2cfb8945e1ff992f54d74d298a658b90.jpg','142647','2011-10-26','admin','2011-10-26 19:28:38','245','[URL]2cfb8945e1ff992f54d74d298a658b90.jpg','1','0','151','0','0');");
E_D("replace into `phome_enewsfile` values('94','354b57c57aef8d2cd4981d85089accb2.jpg','133697','2011-10-26','admin','2011-10-26 19:28:39','245','[URL]354b57c57aef8d2cd4981d85089accb2.jpg','1','0','151','0','0');");
E_D("replace into `phome_enewsfile` values('95','bed478def2b42e47d5c0c25b9a25e675.jpg','133535','2011-10-26','admin','2011-10-26 19:28:40','245','[URL]bed478def2b42e47d5c0c25b9a25e675.jpg','1','0','151','0','0');");
E_D("replace into `phome_enewsfile` values('96','a7fce737a1ddaf5d304a6a9292350db7.jpg','69990','2011-10-26','admin','2011-10-26 19:29:17','245','[URL]a7fce737a1ddaf5d304a6a9292350db7.jpg','1','0','153','0','0');");
E_D("replace into `phome_enewsfile` values('97','c21913ca022dd61c98e2ba2c63d27917.jpg','108548','2011-10-26','admin','2011-10-26 19:30:03','245','[URL]c21913ca022dd61c98e2ba2c63d27917.jpg','1','0','156','0','0');");
E_D("replace into `phome_enewsfile` values('98','62b3e568e5c6f2f9b8cb4f128a1b1892.jpg','3431','2011-10-26','admin','2011-10-26 19:34:38','249','[URL]62b3e568e5c6f2f9b8cb4f128a1b1892.jpg','1','0','165','0','0');");
E_D("replace into `phome_enewsfile` values('99','e8e128bc11f3116268d3431d7fe88fbe.jpg','3378','2011-10-26','admin','2011-10-26 19:34:38','249','[URL]e8e128bc11f3116268d3431d7fe88fbe.jpg','1','0','165','0','0');");
E_D("replace into `phome_enewsfile` values('100','fb09664a4e9186907769499d3d8ce56a.jpg','39941','2011-10-26','admin','2011-10-26 19:40:07','245','[URL]fb09664a4e9186907769499d3d8ce56a.jpg','1','0','149','0','0');");
E_D("replace into `phome_enewsfile` values('101','06da37dbb2b1f6206e16f596db6d555e.jpg','99237','2011-10-26','admin','2011-10-26 19:44:15','245','1b5939ebff7f183ab7301e14b1791a97.jpg','1','0','169','0','0');");
E_D("replace into `phome_enewsfile` values('102','f1d6efbeabd7be7ac032723f515683bf.jpg','131370','2011-10-26','admin','2011-10-26 19:46:19','245','[URL]f1d6efbeabd7be7ac032723f515683bf.jpg','1','0','170','0','0');");
E_D("replace into `phome_enewsfile` values('103','380f3cedb2d9b606ccfb80b8d99e5ca7.jpg','28521','2011-10-26','admin','2011-10-26 19:46:35','245','[URL]380f3cedb2d9b606ccfb80b8d99e5ca7.jpg','1','0','171','0','0');");
E_D("replace into `phome_enewsfile` values('104','013d06b9f3fd9972f9d20981345cdc8f.doc','37894','2011-10-26','admin','2011-10-26 20:18:58','44','2-110914151623.doc','0','0','178','0','0');");
E_D("replace into `phome_enewsfile` values('105','c9c52a05c1a94e88b0e4c1d1c96d8527.doc','39072','2011-10-26','admin','2011-10-26 20:19:46','44','2-110914151G5.doc','0','0','179','0','0');");
E_D("replace into `phome_enewsfile` values('106','f1c0a226d6de02e6a1cd0a683818cf1b.doc','47986','2011-10-26','admin','2011-10-26 20:20:20','44','2-110914151J6.doc','0','0','180','0','0');");
E_D("replace into `phome_enewsfile` values('107','a5d184ebb3c561d3aa5725ed086a5522.doc','57269','2011-10-26','admin','2011-10-26 20:20:49','44','2-110914151P8.doc','0','0','181','0','0');");
E_D("replace into `phome_enewsfile` values('108','add41b77c87dff95c9a5df9418bab5af.jpg','75274','2011-10-26','admin','2011-10-26 20:37:02','46','[URL]add41b77c87dff95c9a5df9418bab5af.jpg','1','0','191','0','0');");
E_D("replace into `phome_enewsfile` values('109','e7bbcb402bd0bd6579d2c265fcff9728.jpg','81613','2011-10-26','admin','2011-10-26 20:37:03','46','[URL]e7bbcb402bd0bd6579d2c265fcff9728.jpg','1','0','191','0','0');");
E_D("replace into `phome_enewsfile` values('110','b01a5413bb1fa1d05d8dbec0371ce06b.jpg','72624','2011-10-26','admin','2011-10-26 20:38:06','46','[URL]b01a5413bb1fa1d05d8dbec0371ce06b.jpg','1','0','192','0','0');");
E_D("replace into `phome_enewsfile` values('111','408b3698e8e5503a35e21534642cc8a9.jpg','111239','2011-10-26','admin','2011-10-26 20:38:07','46','[URL]408b3698e8e5503a35e21534642cc8a9.jpg','1','0','192','0','0');");
E_D("replace into `phome_enewsfile` values('112','cd8ad951d10339535872d4419b287671.jpg','108933','2011-10-26','admin','2011-10-26 20:38:07','46','[URL]cd8ad951d10339535872d4419b287671.jpg','1','0','192','0','0');");
E_D("replace into `phome_enewsfile` values('113','1156d9ca71e9782c40ab7663bc857beb.jpg','249067','2011-10-26','admin','2011-10-26 20:39:23','46','[URL]1156d9ca71e9782c40ab7663bc857beb.jpg','1','0','193','0','0');");
E_D("replace into `phome_enewsfile` values('114','77657880f138c58f8198153354c9f3d1.jpg','263382','2011-10-26','admin','2011-10-26 20:39:24','46','[URL]77657880f138c58f8198153354c9f3d1.jpg','1','0','193','0','0');");
E_D("replace into `phome_enewsfile` values('115','a0b72f19d0cd4b813cd735259a374378.jpg','285035','2011-10-26','admin','2011-10-26 20:39:25','46','[URL]a0b72f19d0cd4b813cd735259a374378.jpg','1','0','193','0','0');");
E_D("replace into `phome_enewsfile` values('116','39b7220df1bd7ace4db793fbf2e3ddd6.jpg','241593','2011-10-26','admin','2011-10-26 20:42:42','46','[URL]39b7220df1bd7ace4db793fbf2e3ddd6.jpg','1','0','194','0','0');");
E_D("replace into `phome_enewsfile` values('117','0f357274e20ebf9c5b5c057525a57459.jpg','303189','2011-10-26','admin','2011-10-26 20:42:44','46','[URL]0f357274e20ebf9c5b5c057525a57459.jpg','1','0','194','0','0');");
E_D("replace into `phome_enewsfile` values('118','5ab9be5d8aded0ac671ffd46c273fbb5.jpg','355456','2011-10-26','admin','2011-10-26 20:42:45','46','[URL]5ab9be5d8aded0ac671ffd46c273fbb5.jpg','1','0','194','0','0');");
E_D("replace into `phome_enewsfile` values('119','a71caf37a8cbc1cb22a36876d565f44c.jpg','179950','2011-10-26','admin','2011-10-26 20:50:40','245','afc60b52c9.jpg','1','0','150','0','0');");
E_D("replace into `phome_enewsfile` values('120','3fe759ea10484ed1d2839bd65ecec29a.doc','41984','2011-10-26','admin','2011-10-26 21:07:47','48','2-110914161038.doc','0','0','227','0','0');");
E_D("replace into `phome_enewsfile` values('121','09b5b18eb04592176b7a7bbf1d61b25c.doc','52736','2011-10-26','admin','2011-10-26 21:10:01','48','2-110914161206.doc','0','0','228','0','0');");
E_D("replace into `phome_enewsfile` values('122','dcf5f38c45a92ba209e05336188e38fb.doc','37888','2011-10-26','admin','2011-10-26 21:10:42','48','�ɿ�Ȩ��������Ǽ���.doc','0','0','229','0','0');");
E_D("replace into `phome_enewsfile` values('123','1fd3a331a84f8c621ffb0c88fe861372.doc','41472','2011-10-26','admin','2011-10-26 21:11:39','48','2-110914161548.doc','0','0','230','0','0');");
E_D("replace into `phome_enewsfile` values('124','f413043b8acd0124ea77dcf7b3ba8d49.doc','68096','2011-10-26','admin','2011-10-26 21:12:25','48','2-110914161F9.doc','0','0','231','0','0');");
E_D("replace into `phome_enewsfile` values('125','274f806cbff7763ecb4a7cdf004f724e.doc','47616','2011-10-26','admin','2011-10-26 21:13:09','48','2-110914161915.doc','0','0','232','0','0');");
E_D("replace into `phome_enewsfile` values('126','2aaa2c84889a9175d987310057aa121f.doc','157696','2011-10-26','admin','2011-10-26 21:14:14','48','2-110914162137.doc','0','0','233','0','0');");
E_D("replace into `phome_enewsfile` values('127','1f8a681841b592c872d8b3dbe633efda.doc','86528','2011-10-26','admin','2011-10-26 21:14:59','48','2-110914162359.doc','0','0','234','0','0');");
E_D("replace into `phome_enewsfile` values('128','ad0b625f655047040ba801f73f9994fb.doc','54784','2011-10-26','admin','2011-10-26 21:16:18','48','2-110914162602.doc','0','0','236','0','0');");
E_D("replace into `phome_enewsfile` values('129','73c403c20d63accff3ec4b7c60578bb8.doc','313856','2011-10-26','admin','2011-10-26 21:17:00','48','2-110914162J2.doc','0','0','237','0','0');");
E_D("replace into `phome_enewsfile` values('130','32e2ea4171e374cbd66dc23f74a758a2.doc','47616','2011-10-26','admin','2011-10-26 21:17:43','48','2-110914162U9.doc','0','0','238','0','0');");
E_D("replace into `phome_enewsfile` values('131','655bf8b5e791faf596ffd78711d79e08.doc','58880','2011-10-26','admin','2011-10-26 21:18:37','48','2-110914163037.doc','0','0','239','0','0');");
E_D("replace into `phome_enewsfile` values('132','1235bee2481291679406d6cdb52404be.doc','53760','2011-10-26','admin','2011-10-26 21:19:48','49','2-110914163P7.doc','0','0','241','0','0');");
E_D("replace into `phome_enewsfile` values('133','08c600913fc96e65ac19143f5f59ce14.doc','95744','2011-10-26','admin','2011-10-26 21:20:44','49','2-110914163934.doc','0','0','242','0','0');");
E_D("replace into `phome_enewsfile` values('134','8b67ec3c92d13edf9cc9aa00cee9cb98.doc','29184','2011-10-26','admin','2011-10-26 21:21:46','49','2-110914164057.doc','0','0','244','0','0');");
E_D("replace into `phome_enewsfile` values('135','2d3fb1f3e589a331bd9ca414a19f4d7b.jpg','119294','2011-10-26','admin','2011-10-26 21:31:13','53','[URL]2d3fb1f3e589a331bd9ca414a19f4d7b.jpg','1','0','262','0','0');");
E_D("replace into `phome_enewsfile` values('136','926c9f212f7579d685b20b5b4617c552.doc','63488','2011-10-26','admin','2011-10-26 22:18:37','58','2-1109141G631.doc','0','0','300','0','0');");
E_D("replace into `phome_enewsfile` values('137','3b77898eaffc2ccd590cb21b64f6e189.doc','67584','2011-10-26','admin','2011-10-26 22:19:12','58','2-1109141GA5.doc','0','0','300','0','0');");
E_D("replace into `phome_enewsfile` values('138','6423fad2db429d3d2f44066562424e85.doc','96256','2011-10-26','admin','2011-10-26 22:19:42','58','2-1109141GH1.doc','0','0','300','0','0');");
E_D("replace into `phome_enewsfile` values('139','8ae8837df824c6501649a6cba2730ea0.doc','67072','2011-10-26','admin','2011-10-26 22:20:00','58','2-1109141GK0.doc','0','0','300','0','0');");
E_D("replace into `phome_enewsfile` values('140','4c5072d5c3f5803b417f9282f7bd7468.doc','40960','2011-10-26','admin','2011-10-26 22:20:17','58','2-1109141GQ7.doc','0','0','300','0','0');");
E_D("replace into `phome_enewsfile` values('141','2ef5b5a43069a2dd60d4713a6620eb88.doc','150528','2011-10-26','admin','2011-10-26 22:25:13','61','2-1109141HF0.doc','0','0','306','0','0');");
E_D("replace into `phome_enewsfile` values('142','035f36e6c56f515c87d59f0306bc6386.doc','41472','2011-10-26','admin','2011-10-26 22:25:33','61','2-1109141HI2.doc','0','0','306','0','0');");
E_D("replace into `phome_enewsfile` values('143','0d18a025e2fbf80ecbf7b1d684dd561b.jpg','109032','2011-10-26','admin','2011-10-26 22:44:39','68','[URL]0d18a025e2fbf80ecbf7b1d684dd561b.jpg','1','0','360','0','0');");
E_D("replace into `phome_enewsfile` values('144','0700ac1e486b922ca06a0ff77f0224ee.jpg','181149','2011-10-26','admin','2011-10-26 22:48:23','70','[URL]0700ac1e486b922ca06a0ff77f0224ee.jpg','1','0','372','0','0');");
E_D("replace into `phome_enewsfile` values('145','6435e6cbd37732d635827e0ee11e3bcf.jpg','179657','2011-10-26','admin','2011-10-26 22:48:24','70','[URL]6435e6cbd37732d635827e0ee11e3bcf.jpg','1','0','372','0','0');");
E_D("replace into `phome_enewsfile` values('146','532282d9deec2adef423868761a9001f.jpg','129640','2011-10-26','admin','2011-10-26 22:48:25','70','[URL]532282d9deec2adef423868761a9001f.jpg','1','0','372','0','0');");
E_D("replace into `phome_enewsfile` values('147','d0fbe4b8d87a61528686664bb78232a5.jpg','66609','2011-10-26','admin','2011-10-26 22:48:25','70','[URL]d0fbe4b8d87a61528686664bb78232a5.jpg','1','0','372','0','0');");
E_D("replace into `phome_enewsfile` values('148','5d74b7b0059a4aab922442f1b920cc1c.gif','681','2011-10-26','admin','2011-10-26 22:48:26','70','[URL]5d74b7b0059a4aab922442f1b920cc1c.gif','1','0','372','0','0');");
E_D("replace into `phome_enewsfile` values('149','ce0920eea45945edef7300ab9ea42698.gif','681','2011-10-26','admin','2011-10-26 22:48:26','70','[URL]ce0920eea45945edef7300ab9ea42698.gif','1','0','372','0','0');");
E_D("replace into `phome_enewsfile` values('150','ba362dd8479da82eecd81b15f0ddb8cd.gif','681','2011-10-26','admin','2011-10-26 22:48:26','70','[URL]ba362dd8479da82eecd81b15f0ddb8cd.gif','1','0','372','0','0');");
E_D("replace into `phome_enewsfile` values('151','899793039fd408dcafcf1a5dd742d300.jpg','58354','2011-10-26','admin','2011-10-26 22:48:26','70','[URL]899793039fd408dcafcf1a5dd742d300.jpg','1','0','372','0','0');");
E_D("replace into `phome_enewsfile` values('152','af65f0ff092fc9f5a478b3c1f069d506.jpg','71352','2011-10-26','admin','2011-10-26 22:48:27','70','[URL]af65f0ff092fc9f5a478b3c1f069d506.jpg','1','0','372','0','0');");
E_D("replace into `phome_enewsfile` values('153','1316320a5083ce917c090de02363abeb.jpg','129623','2011-10-26','admin','2011-10-26 22:48:28','70','[URL]1316320a5083ce917c090de02363abeb.jpg','1','0','372','0','0');");
E_D("replace into `phome_enewsfile` values('154','cbfa5120247527f31323f9982f8253c6.jpg','105609','2011-10-26','admin','2011-10-26 22:48:28','70','[URL]cbfa5120247527f31323f9982f8253c6.jpg','1','0','372','0','0');");
E_D("replace into `phome_enewsfile` values('155','7b092db6659d8c7cdc28c920fd2f51ac.jpg','61927','2011-10-26','admin','2011-10-26 22:48:29','70','[URL]7b092db6659d8c7cdc28c920fd2f51ac.jpg','1','0','372','0','0');");
E_D("replace into `phome_enewsfile` values('156','52cf3005620e54a50448516d60bfc0d7.jpg','150471','2011-10-27','admin','2011-10-27 01:38:13','268','[URL]52cf3005620e54a50448516d60bfc0d7.jpg','1','0','421','0','0');");
E_D("replace into `phome_enewsfile` values('157','4cf80dce111934ea57078e9d7dcd756e.jpg','66036','2011-10-27','admin','2011-10-27 01:40:58','269','[URL]4cf80dce111934ea57078e9d7dcd756e.jpg','1','0','427','0','0');");
E_D("replace into `phome_enewsfile` values('158','d6712e3ec7c2d9c7577990c66df93ce9.jpg','86075','2011-10-27','admin','2011-10-27 01:40:59','269','[URL]d6712e3ec7c2d9c7577990c66df93ce9.jpg','1','0','427','0','0');");
E_D("replace into `phome_enewsfile` values('196','22a25e9373dbbef3e719317f1e3e2112.doc','1324544','2011-11-08','admin','2011-11-08 11:58:48','277','�շ���Ŀ��׼���.doc','0','0','724','0','0');");
E_D("replace into `phome_enewsfile` values('161','ed745c154e79dbbcc93b99d055aa0c14.xls','713216','2011-10-27','admin','2011-10-27 20:06:27','76','2-110929151911.xls','0','0','467','0','0');");
E_D("replace into `phome_enewsfile` values('162','dd1d47ca37d92a6408a3786817bbfac1.doc','21504','2011-10-27','admin','2011-10-27 20:06:54','76','2-110929153510.doc','0','0','467','0','0');");
E_D("replace into `phome_enewsfile` values('163','39c16f5585bd2966bcf4d67b9e09ee65.gif','13796','2011-10-27','admin','2011-10-27 20:18:04','76','[URL]39c16f5585bd2966bcf4d67b9e09ee65.gif','1','0','477','0','0');");
E_D("replace into `phome_enewsfile` values('164','20f697f9609cf74c1640330747f518b9.jpg','64552','2011-10-27','admin','2011-10-27 20:23:07','76','[URL]20f697f9609cf74c1640330747f518b9.jpg','1','0','482','0','0');");
E_D("replace into `phome_enewsfile` values('165','80169f9a3faf52bb3daea433ea3742ca.jpg','67730','2011-10-27','admin','2011-10-27 20:26:45','76','[URL]80169f9a3faf52bb3daea433ea3742ca.jpg','1','0','486','0','0');");
E_D("replace into `phome_enewsfile` values('166','e18c5afd312a947b23478c7fa45f5113.jpg','31479','2011-10-27','admin','2011-10-27 20:38:37','76','[URL]e18c5afd312a947b23478c7fa45f5113.jpg','1','0','496','0','0');");
E_D("replace into `phome_enewsfile` values('167','a45f9d34b7345595dc710bf042625108.jpg','68238','2011-10-27','admin','2011-10-27 20:38:48','76','[URL]a45f9d34b7345595dc710bf042625108.jpg','1','0','495','0','0');");
E_D("replace into `phome_enewsfile` values('168','1c4b5b021320176aafcc88b875ce5c79.jpg','190654','2011-10-27','admin','2011-10-27 21:58:56','6','2011102717912352.jpg','1','0','502','0','0');");
E_D("replace into `phome_enewsfile` values('209','50747b7741494562a7d4ee9baae8aa7b.jpg','44216','2011-11-21','admin','2011-11-21 23:01:44','280','[URL]50747b7741494562a7d4ee9baae8aa7b.jpg','1','0','900','0','0');");
E_D("replace into `phome_enewsfile` values('210','851e7b5e3f7a5dd2c3dab03f9470112a.jpg','202159','2011-11-22','jiayuadmin','2011-11-22 10:04:56','6','[URL]851e7b5e3f7a5dd2c3dab03f9470112a.jpg','1','0','917','0','0');");
E_D("replace into `phome_enewsfile` values('211','900b27979c6ffe3a744d4262845ae0ed.jpg','147215','2011-11-22','jiayuadmin','2011-11-22 10:04:56','6','[URL]900b27979c6ffe3a744d4262845ae0ed.jpg','1','0','917','0','0');");
E_D("replace into `phome_enewsfile` values('212','f63fb993c85644a4e018d216e2521df0.jpg','212540','2011-11-22','jiayuadmin','2011-11-22 10:05:33','6','[URL]f63fb993c85644a4e018d216e2521df0.jpg','1','0','857','0','0');");
E_D("replace into `phome_enewsfile` values('213','5d615afb4aae8ca57c701f306a481d25.jpg','165939','2011-11-22','jiayuadmin','2011-11-22 10:06:02','6','[URL]5d615afb4aae8ca57c701f306a481d25.jpg','1','0','824','0','0');");
E_D("replace into `phome_enewsfile` values('214','4afafec350b518b5321551d1bdd74e73.jpg','208105','2011-11-22','jiayuadmin','2011-11-22 10:06:03','6','[URL]4afafec350b518b5321551d1bdd74e73.jpg','1','0','824','0','0');");
E_D("replace into `phome_enewsfile` values('215','5f991ed7d12d3d3b87591f1480dba3a0.jpg','179018','2011-11-22','jiayuadmin','2011-11-22 16:56:47','6','[URL]5f991ed7d12d3d3b87591f1480dba3a0.jpg','1','0','919','0','0');");
E_D("replace into `phome_enewsfile` values('216','8c96df230662421626e38ab3eb4276d0.jpg','178511','2011-11-22','jiayuadmin','2011-11-22 19:40:26','6','[URL]8c96df230662421626e38ab3eb4276d0.jpg','1','0','921','0','0');");
E_D("replace into `phome_enewsfile` values('217','6027d382d029c319d5caf79639b2aebf.jpg','179175','2011-11-22','jiayuadmin','2011-11-22 19:40:26','6','[URL]6027d382d029c319d5caf79639b2aebf.jpg','1','0','921','0','0');");
E_D("replace into `phome_enewsfile` values('218','3ee3077fa87755daaf9bc18546bbbfef.jpg','142451','2011-11-22','jiayuadmin','2011-11-22 22:04:38','6','[URL]3ee3077fa87755daaf9bc18546bbbfef.jpg','1','0','922','0','0');");
E_D("replace into `phome_enewsfile` values('219','bd453810bdf087b5cc50f66bcedcd9aa.jpg','27537','2011-11-23','admin','2011-11-23 09:19:29','283','[URL]bd453810bdf087b5cc50f66bcedcd9aa.jpg','1','0','923','0','0');");
E_D("replace into `phome_enewsfile` values('220','633224402de6383c6b261953a15a8de8.jpg','41887','2011-11-23','admin','2011-11-23 09:21:10','283','[URL]633224402de6383c6b261953a15a8de8.jpg','1','0','924','0','0');");
E_D("replace into `phome_enewsfile` values('221','b428dfa9d2abc49c8ca164f8b151fd34.jpg','38976','2011-11-23','admin','2011-11-23 09:22:08','283','[URL]b428dfa9d2abc49c8ca164f8b151fd34.jpg','1','0','925','0','0');");
E_D("replace into `phome_enewsfile` values('222','aab8b0286f1e77f755b7cc8672129bd9.jpg','38530','2011-11-23','admin','2011-11-23 09:23:14','283','[URL]aab8b0286f1e77f755b7cc8672129bd9.jpg','1','0','926','0','0');");
E_D("replace into `phome_enewsfile` values('223','d345352ef7dc41e206b221ae16b1abc5.jpg','33136','2011-11-23','admin','2011-11-23 09:27:43','283','[URL]d345352ef7dc41e206b221ae16b1abc5.jpg','1','0','928','0','0');");
E_D("replace into `phome_enewsfile` values('224','d777ec53b8282747f5aefb87063822de.jpg','38235','2011-11-23','admin','2011-11-23 09:27:51','283','[URL]d777ec53b8282747f5aefb87063822de.jpg','1','0','927','0','0');");
E_D("replace into `phome_enewsfile` values('225','96a48c974960ffe7d5db022a43a6b5e2.jpg','142344','2011-11-23','jiayuadmin','2011-11-23 17:16:14','6','[URL]96a48c974960ffe7d5db022a43a6b5e2.jpg','1','0','930','0','0');");
E_D("replace into `phome_enewsfile` values('244','84ea4bf9aad508905a1a0c14df3395e7.jpg','174571','2011-11-24','jiayuadmin','2011-11-24 18:47:54','6','[URL]84ea4bf9aad508905a1a0c14df3395e7.jpg','1','0','937','0','0');");
E_D("replace into `phome_enewsfile` values('238','3c25fbcbff25da9a520c5604081ed349.jpg','75241','2011-11-24','admin','2011-11-24 16:12:50','283','17bc8abfb968cbee7e599969e592c43f.jpg','1','0','928','0','0');");
E_D("replace into `phome_enewsfile` values('239','16f71019f451e96ef1380a8f7589beb7.jpg','75504','2011-11-24','admin','2011-11-24 16:20:55','283','���������칫¥_����.jpg','1','0','925','0','0');");
E_D("replace into `phome_enewsfile` values('240','5519fb9fa39e63ef82276849c566ee56.jpg','58731','2011-11-24','admin','2011-11-24 16:21:24','283','����������3_����.jpg','1','0','927','0','0');");
E_D("replace into `phome_enewsfile` values('241','d1f7ded0ec72cc2fb9a41f49160576a9.jpg','57592','2011-11-24','jiayuadmin','2011-11-24 17:15:24','283','IMG_3859_����.jpg','1','0','923','0','0');");
E_D("replace into `phome_enewsfile` values('242','0dd839c31a835ca7411b9469daa6672c.jpg','157620','2011-11-24','jiayuadmin','2011-11-24 17:20:02','6','[URL]0dd839c31a835ca7411b9469daa6672c.jpg','1','0','936','0','0');");
E_D("replace into `phome_enewsfile` values('243','d186af5391998725dd9cebc1d08f2f6d.jpg','154770','2011-11-24','jiayuadmin','2011-11-24 17:20:03','6','[URL]d186af5391998725dd9cebc1d08f2f6d.jpg','1','0','936','0','0');");
E_D("replace into `phome_enewsfile` values('245','996e0429a06fbeb0d1bd69309884ab61.jpg','191537','2011-11-24','jiayuadmin','2011-11-24 18:47:55','6','[URL]996e0429a06fbeb0d1bd69309884ab61.jpg','1','0','937','0','0');");
E_D("replace into `phome_enewsfile` values('246','efffdab5585a40f27f8683f3787aeea1.jpg','61532','2011-11-25','jiayuadmin','2011-11-25 10:31:19','283','DSC04141_����.jpg','1','0','926','0','0');");
E_D("replace into `phome_enewsfile` values('247','539a751ef954abdfc53015c533cc43b7.jpg','190151','2011-11-25','jiayuadmin','2011-11-25 20:48:41','6','[URL]539a751ef954abdfc53015c533cc43b7.jpg','1','0','967','0','0');");
E_D("replace into `phome_enewsfile` values('248','457ab935c5ebb8d482a6afba4596c252.jpg','125113','2011-11-25','jiayuadmin','2011-11-25 20:51:23','6','[URL]457ab935c5ebb8d482a6afba4596c252.jpg','1','0','968','0','0');");
E_D("replace into `phome_enewsfile` values('249','b1ebb84d2ce901df5d2bd4624956346a.jpg','137809','2011-11-25','jiayuadmin','2011-11-25 20:51:23','6','[URL]b1ebb84d2ce901df5d2bd4624956346a.jpg','1','0','968','0','0');");
E_D("replace into `phome_enewsfile` values('250','521b444b069bd6f49479937d050b4137.jpg','177220','2011-11-28','jiayuadmin','2011-11-28 14:56:40','79','[URL]521b444b069bd6f49479937d050b4137.jpg','1','0','994','0','0');");
E_D("replace into `phome_enewsfile` values('251','a0294d6deb78927a2a697c08a1912193.jpg','183535','2011-11-28','jiayuadmin','2011-11-28 14:56:41','79','[URL]a0294d6deb78927a2a697c08a1912193.jpg','1','0','994','0','0');");
E_D("replace into `phome_enewsfile` values('252','b07a0a8d83a815327d0482bf8ee2b3bd.jpg','77883','2011-11-28','jiayuadmin','2011-11-28 17:09:31','283','333_����.jpg','1','0','924','0','0');");
E_D("replace into `phome_enewsfile` values('253','f8f5dc63249277a46dab480c976a5e5a.doc','133632','2011-11-29','jiayuadmin','2011-11-29 09:41:05','186','����������������','0','0','662','0','0');");
E_D("replace into `phome_enewsfile` values('254','d8fc29be71e996f3151c5596f28f680e.doc','58368','2011-11-29','jiayuadmin','2011-11-29 09:41:35','186','����������������','0','0','662','0','0');");
E_D("replace into `phome_enewsfile` values('255','4269abe93aafba6a4851603fa797a73b.doc','32256','2011-11-29','jiayuadmin','2011-11-29 09:50:01','186','����׶�԰���ñ�׼','0','0','657','0','0');");
E_D("replace into `phome_enewsfile` values('256','d14d1b8fcc4e2f6a981b3b2901174a6d.doc','98816','2011-11-29','jiayuadmin','2011-11-29 09:51:31','186','����׶�԰����','0','0','657','0','0');");
E_D("replace into `phome_enewsfile` values('257','559d97fc3d1407a6ca556b28cfe9f9a0.doc','21504','2011-11-29','jiayuadmin','2011-11-29 09:52:23','186','��ѧ������ͬ�������׶�԰������','0','0','657','0','0');");
E_D("replace into `phome_enewsfile` values('258','28fffe1ac69707d8e0465d633f20f009.jpg','158489','2011-11-29','jiayuadmin','2011-11-29 18:16:25','6','[URL]28fffe1ac69707d8e0465d633f20f009.jpg','1','0','1022','0','0');");
E_D("replace into `phome_enewsfile` values('259','5d61aad1a254f19c033e916c751b3e91.jpg','139781','2011-11-30','jiayuadmin','2011-11-30 18:38:56','6','[URL]5d61aad1a254f19c033e916c751b3e91.jpg','1','0','1024','0','0');");
E_D("replace into `phome_enewsfile` values('260','908edc1a5e7e88304e3e201e7b653a01.jpg','186248','2011-11-30','jiayuadmin','2011-11-30 18:39:58','6','[URL]908edc1a5e7e88304e3e201e7b653a01.jpg','1','0','1025','0','0');");
E_D("replace into `phome_enewsfile` values('261','13608f607171308b993ad8eed0b5eb81.jpg','208758','2011-11-30','jiayuadmin','2011-11-30 20:34:18','6','[URL]13608f607171308b993ad8eed0b5eb81.jpg','1','0','1027','0','0');");

@include("../../inc/footer.php");
?>