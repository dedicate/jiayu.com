<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `phome_enewssearch`;");
E_C("CREATE TABLE `phome_enewssearch` (
  `searchid` bigint(20) NOT NULL auto_increment,
  `keyboard` varchar(255) NOT NULL default '',
  `searchtime` int(11) NOT NULL default '0',
  `searchclass` varchar(255) NOT NULL default '',
  `result_num` int(11) NOT NULL default '0',
  `searchip` varchar(20) NOT NULL default '',
  `classid` varchar(255) NOT NULL default '',
  `onclick` int(11) NOT NULL default '0',
  `orderby` varchar(30) NOT NULL default '0',
  `myorder` tinyint(1) NOT NULL default '0',
  `checkpass` varchar(32) NOT NULL default '',
  `tbname` varchar(60) NOT NULL default '',
  `tempid` smallint(6) NOT NULL default '0',
  `iskey` tinyint(1) NOT NULL default '0',
  `andsql` text NOT NULL,
  `trueclassid` smallint(6) NOT NULL default '0',
  PRIMARY KEY  (`searchid`),
  KEY `checkpass` (`checkpass`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=gbk");
E_D("replace into `phome_enewssearch` values('1','��ǹ','1319720524','title','1','111.179.12.81','0','3','newstime','0','c73689dd2619072daa7b5f074d5f481a','news','0','0',' and ((title LIKE ''%��ǹ%''))','0');");
E_D("replace into `phome_enewssearch` values('2','��Ʊ','1319720017','title','2','121.61.86.135','0','1','newstime','0','583569d0095427bd55024cd465f75194','news','0','0',' and ((title LIKE ''%��Ʊ%''))','0');");
E_D("replace into `phome_enewssearch` values('3','����','1319721979','title','2','121.61.86.135','0','5','newstime','0','17d40c630f6dc0154c3af9730374fb93','news','0','0',' and ((title LIKE ''%����%''))','0');");
E_D("replace into `phome_enewssearch` values('4','�滮','1319721880','title','11','121.61.86.135','0','4','newstime','0','fcbd1a906676df0276f59402c119e0c6','news','0','0',' and ((title LIKE ''%�滮%''))','0');");
E_D("replace into `phome_enewssearch` values('5','����','1319722032','title','1','121.61.86.135','0','1','newstime','0','e604717ab0f1392b6db8034006f79916','news','0','0',' and ((title LIKE ''%����%''))','0');");
E_D("replace into `phome_enewssearch` values('6','�ӵ�','1319722539','title','4','121.61.86.135','0','1','newstime','0','39ebc4836088d25b95b0aa2eac6fa0c6','news','0','0',' and ((title LIKE ''%�ӵ�%''))','0');");
E_D("replace into `phome_enewssearch` values('7','Сѧ','1319736893','title','2','121.61.86.135','0','1','newstime','0','a276e032d19c32de78dc201b33443707','news','0','0',' and ((title LIKE ''%Сѧ%''))','0');");
E_D("replace into `phome_enewssearch` values('8','Э��','1319737835','title','2','121.61.86.135','0','1','newstime','0','2a4d9ec5d7456079c418bf6e201d4239','news','0','0',' and ((title LIKE ''%Э��%''))','0');");
E_D("replace into `phome_enewssearch` values('9','����','1320080286','title','5','111.179.14.137','0','1','newstime','0','3059f2b69d8c70d34c641899e53c914d','news','0','0',' and ((title LIKE ''%����%''))','0');");
E_D("replace into `phome_enewssearch` values('10','������','1322628191','title','13','127.0.0.1','0','3','newstime','0','24e82c4081d25e02c2e13f3a06c1efb2','news','0','0',' and ((title LIKE ''%������%''))','0');");
E_D("replace into `phome_enewssearch` values('11','�˷�','1320497950','title','6','121.61.89.238','0','1','newstime','0','279237f364165d6854a518aee7854766','news','0','0',' and ((title LIKE ''%�˷�%''))','0');");
E_D("replace into `phome_enewssearch` values('12','���㾭�ÿ�����','1320498021','title','2','121.61.89.238','0','1','newstime','0','0ff8a09ba617d4e4b4a7627fc45aa00a','news','0','0',' and ((title LIKE ''%���㾭�ÿ�����%''))','0');");
E_D("replace into `phome_enewssearch` values('13','����','1321781038','title','1','127.0.0.1','0','2','newstime','0','08740a511a73a4a8c028bde50ea9255a','news','0','0',' and ((title LIKE ''%����%''))','0');");
E_D("replace into `phome_enewssearch` values('14','������������','1321931831','title','1','111.179.10.67','0','2','newstime','0','cee1d8a96c8b6a766a29a5f657f0c1bf','news','0','0',' and ((title LIKE ''%������������%''))','0');");
E_D("replace into `phome_enewssearch` values('15','������','1321952657','title','9','111.179.13.110','0','1','newstime','0','d96b8319e4fb1ad597c67e5d72a12686','news','0','0',' and ((title LIKE ''%������%''))','0');");
E_D("replace into `phome_enewssearch` values('16','����','1321971124','title,smalltext','1','121.61.81.32','0','1','newstime','0','da4b0eef56ac45e0b5cf16fba79f7900','news','0','0',' and ((title LIKE ''%����%'') or (smalltext LIKE ''%����%''))','0');");
E_D("replace into `phome_enewssearch` values('17','������','1322374170','title','2','123.150.183.125','0','4','newstime','0','24b4ef6fcbf6e8b990e0fba274b7db11','news','0','0',' and ((title LIKE ''%������%''))','0');");
E_D("replace into `phome_enewssearch` values('18','����','1322039454','title,smalltext','6','218.89.178.22','0','1','newstime','0','8e713d3cd66c48d54aee31f22a93b2ce','news','0','0',' and ((title LIKE ''%����%'') or (smalltext LIKE ''%����%''))','0');");
E_D("replace into `phome_enewssearch` values('19','�ֹ�','1322061261','title','2','121.61.80.10','0','1','newstime','0','1392732e45b069fe326c68dfd8e27019','news','0','0',' and ((title LIKE ''%�ֹ�%''))','0');");
E_D("replace into `phome_enewssearch` values('20','���ϱ���','1322387718','title','2','119.131.149.49','0','1','newstime','0','f5d8530691268fd8a925cd095c24eae6','news','0','0',' and ((title LIKE ''%���ϱ���%''))','0');");
E_D("replace into `phome_enewssearch` values('21','��������','1322575299','title','1','117.40.134.2','0','1','newstime','0','dc84efdc5b288c56c26414734c3a4dc0','news','0','0',' and ((title LIKE ''%��������%''))','0');");
E_D("replace into `phome_enewssearch` values('22','��֯��','1322652804','title','1','111.179.31.72','0','1','newstime','0','a95d2b991562356d37dc0ecbb6616d22','news','0','0',' and ((title LIKE ''%��֯��%''))','0');");
E_D("replace into `phome_enewssearch` values('23','����','1322706254','title','2','61.191.21.148','0','1','newstime','0','fb7b4d1a2c5224d81caaeeea687f9c10','news','0','0',' and ((title LIKE ''%����%''))','0');");

@include("../../inc/footer.php");
?>